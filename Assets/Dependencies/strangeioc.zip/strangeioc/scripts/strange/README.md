strange-core
============

StrangeIoC.
v0.7.0
Just the code.

The full StrangeIoC repo is at:
https://github.com/thirdmotion/strangeioc

Documentation and helpful goodies:
http://thirdmotion.github.io/strangeioc/

Follow us on Facebook...
https://www.facebook.com/strangeioc
...or Twitter...
@StrangeIoC
