/// Example Model
/// ======================
/// Nothing to see here. Just your typical place to store some data.

using System;

namespace strange.examples.myfirstproject
{
	public class ExampleModel : IExampleModel
	{
		public string data {get;set;}
		
		public ExampleModel ()
		{
		}
	}
}

