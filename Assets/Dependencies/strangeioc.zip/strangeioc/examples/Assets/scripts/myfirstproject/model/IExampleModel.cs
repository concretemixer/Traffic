using System;

namespace strange.examples.myfirstproject
{
	public interface IExampleModel
	{
		string data{get;set;}
	}
}

