/// A Signal for Starting the Context

using System;
using strange.extensions.signal.impl;

namespace strange.examples.signals
{
	public class StartSignal : Signal
	{
	}
}

