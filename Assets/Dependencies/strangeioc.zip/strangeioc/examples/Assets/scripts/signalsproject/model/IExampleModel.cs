/// No change

using System;

namespace strange.examples.signals
{
	public interface IExampleModel
	{
		string data{get;set;}
	}
}

