/// No change

using System;

namespace strange.examples.signals
{
	public class ExampleModel : IExampleModel
	{
		public string data {get;set;}
		
		public ExampleModel ()
		{
		}
	}
}

