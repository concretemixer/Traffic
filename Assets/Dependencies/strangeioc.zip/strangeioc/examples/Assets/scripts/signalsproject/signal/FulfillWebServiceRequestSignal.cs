/// A Signal which hands back an URL
/// 
/// string The URL

using System;
using strange.extensions.signal.impl;

namespace strange.examples.signals
{
	public class FulfillWebServiceRequestSignal : Signal<string>
	{
	}
}

